import { useAccessKeys, useGenerateKey, useDeleteKey } from "@/hooks/use-access-keys";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { StatsCard } from "@/components/ui/stats-card";
import { CopyButton } from "@/components/ui/copy-button";
import { 
  Key, 
  Plus, 
  Trash2, 
  Users, 
  ShieldCheck, 
  ShieldAlert, 
  RefreshCw, 
  Bot 
} from "lucide-react";
import { format } from "date-fns";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function Dashboard() {
  const { data: keys = [], isLoading, isError } = useAccessKeys();
  const generateKey = useGenerateKey();
  const deleteKey = useDeleteKey();

  const totalKeys = keys.length;
  const usedKeys = keys.filter(k => k.isUsed).length;
  const unusedKeys = keys.filter(k => !k.isUsed).length;

  if (isError) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-destructive/20 bg-destructive/5">
          <CardHeader>
            <CardTitle className="text-destructive flex items-center gap-2">
              <ShieldAlert className="h-5 w-5" />
              Failed to Load
            </CardTitle>
            <CardDescription>
              Could not fetch access keys. Please try refreshing the page.
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground pb-20">
      {/* Header */}
      <header className="border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-lg">
              <Bot className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold font-display">Bot Access Manager</h1>
              <p className="text-xs text-muted-foreground">Admin Dashboard</p>
            </div>
          </div>
          
          <Button 
            onClick={() => generateKey.mutate()} 
            disabled={generateKey.isPending}
            className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-primary-foreground font-semibold shadow-lg shadow-primary/20 hover:shadow-primary/30 transition-all"
          >
            {generateKey.isPending ? (
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Plus className="h-4 w-4 mr-2" />
            )}
            Generate New Key
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 space-y-8">
        
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <StatsCard 
            title="Total Keys" 
            value={totalKeys} 
            icon={Key} 
            description="All generated access tokens"
          />
          <StatsCard 
            title="Active Users" 
            value={usedKeys} 
            icon={Users} 
            description="Keys claimed by Telegram users"
          />
          <StatsCard 
            title="Available Keys" 
            value={unusedKeys} 
            icon={ShieldCheck} 
            description="Ready for distribution"
          />
        </div>

        {/* Keys List */}
        <Card className="border-border/50 bg-card/50 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <CardTitle className="font-display">Access Keys</CardTitle>
            <CardDescription>
              Manage entry tokens for your Telegram community.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-12 space-y-4">
                <RefreshCw className="h-8 w-8 text-primary animate-spin" />
                <p className="text-muted-foreground text-sm">Loading keys...</p>
              </div>
            ) : keys.length === 0 ? (
              <div className="text-center py-12 px-4 border-2 border-dashed border-border/50 rounded-lg bg-card/30">
                <Key className="h-12 w-12 text-muted-foreground/30 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-foreground">No keys generated</h3>
                <p className="text-muted-foreground text-sm max-w-sm mx-auto mt-2 mb-6">
                  Get started by generating your first access key to invite users to your bot.
                </p>
                <Button 
                  variant="outline"
                  onClick={() => generateKey.mutate()}
                  disabled={generateKey.isPending}
                >
                  Generate First Key
                </Button>
              </div>
            ) : (
              <div className="rounded-md border border-border/50 overflow-hidden">
                <Table>
                  <TableHeader className="bg-muted/50">
                    <TableRow className="hover:bg-transparent">
                      <TableHead className="font-medium">Access Key</TableHead>
                      <TableHead className="font-medium">Status</TableHead>
                      <TableHead className="font-medium">Claimed By</TableHead>
                      <TableHead className="font-medium">Created At</TableHead>
                      <TableHead className="text-right font-medium">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {keys.map((key) => (
                      <TableRow key={key.id} className="hover:bg-muted/30 transition-colors">
                        <TableCell className="font-mono text-xs sm:text-sm">
                          <div className="flex items-center gap-2">
                            <span className="text-foreground/90">{key.key}</span>
                            <CopyButton value={key.key} />
                          </div>
                        </TableCell>
                        <TableCell>
                          {key.isUsed ? (
                            <Badge variant="secondary" className="bg-muted text-muted-foreground hover:bg-muted">
                              Used
                            </Badge>
                          ) : (
                            <Badge className="bg-emerald-500/15 text-emerald-500 hover:bg-emerald-500/25 border-emerald-500/20">
                              Available
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          {key.isUsed ? (
                            <div className="flex flex-col">
                              <span className="text-sm font-medium text-foreground">
                                @{key.telegramUsername || "Unknown"}
                              </span>
                              <span className="text-xs text-muted-foreground font-mono">
                                ID: {key.telegramUserId}
                              </span>
                            </div>
                          ) : (
                            <span className="text-muted-foreground text-sm">-</span>
                          )}
                        </TableCell>
                        <TableCell className="text-muted-foreground text-sm">
                          {format(new Date(key.createdAt), "MMM d, yyyy • HH:mm")}
                        </TableCell>
                        <TableCell className="text-right">
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button 
                                variant="ghost" 
                                size="icon"
                                className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
                              >
                                <Trash2 className="h-4 w-4" />
                                <span className="sr-only">Delete</span>
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Delete Access Key?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This action cannot be undone. This will permanently delete the access key 
                                  <span className="font-mono text-foreground mx-1">{key.key}</span>
                                  from the database.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction 
                                  onClick={() => deleteKey.mutate(key.id)}
                                  className="bg-destructive hover:bg-destructive/90 text-destructive-foreground"
                                >
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
