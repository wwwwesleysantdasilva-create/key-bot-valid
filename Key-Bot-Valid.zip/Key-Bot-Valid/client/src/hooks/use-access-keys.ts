import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useAccessKeys() {
  return useQuery({
    queryKey: [api.keys.list.path],
    queryFn: async () => {
      const res = await fetch(api.keys.list.path);
      if (!res.ok) throw new Error("Failed to fetch access keys");
      return api.keys.list.responses[200].parse(await res.json());
    },
  });
}

export function useGenerateKey() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.keys.generate.path, {
        method: api.keys.generate.method,
      });
      
      if (!res.ok) throw new Error("Failed to generate key");
      return api.keys.generate.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.keys.list.path] });
      toast({
        title: "Key Generated",
        description: "A new access key has been successfully created.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useDeleteKey() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.keys.delete.path, { id });
      const res = await fetch(url, {
        method: api.keys.delete.method,
      });

      if (!res.ok) throw new Error("Failed to delete key");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.keys.list.path] });
      toast({
        title: "Key Deleted",
        description: "The access key has been removed.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
