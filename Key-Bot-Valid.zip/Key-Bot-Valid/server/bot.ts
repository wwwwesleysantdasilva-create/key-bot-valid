import TelegramBot from 'node-telegram-bot-api';
import { IStorage } from './storage';

let bot: TelegramBot | null = null;

const PRODUTOS = {
  "pharmacy": {
    "nome": "🧪 Pharmacy Pack",
    "grupo": "-1003705721917"
  },
  "inject": {
    "nome": "💉 Inject Pack",
    "grupo": "-1003801083393"
  },
  "basic": {
    "nome": "📱 Basic Pack",
    "grupo": "-1003899281136"
  }
};

const PAINEL_IMG = "https://i.postimg.cc/8PcCb5Tb/76CD6DF4-ACD3-41D6-9A8D-03BED69B0041.png";
const estado_usuarios: Record<string, any> = {};

export function startBot(storage: IStorage) {
  const token = process.env.TELEGRAM_BOT_TOKEN;

  if (!token) {
    console.warn("TELEGRAM_BOT_TOKEN not set. Bot will not start.");
    return;
  }

  bot = new TelegramBot(token, { polling: true });

  console.log("Telegram Bot started...");

  bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const text = msg.text?.trim();
    const userId = msg.from?.id.toString();
    const username = msg.from?.username;

    if (!userId) return;

    const ADMIN_ID = "8235876348";

    // START COMMAND
    if (text === '/start') {
      const teclado = {
        reply_markup: {
          inline_keyboard: [
            [{ text: "💻 Resgatar Pack", callback_data: "resgatar_pack" }]
          ]
        }
      };

      bot?.sendPhoto(chatId, PAINEL_IMG, {
        caption: "",
        ...teclado
      });
      return;
    }

    // ADMIN COMMAND: /gerarkey
    if (text === '/gerarkey' && userId === ADMIN_ID) {
      const teclado = {
        reply_markup: {
          inline_keyboard: [
            [{ text: "🧪 Pharmacy Pack", callback_data: "gen_pharmacy" }],
            [{ text: "💉 Inject Pack", callback_data: "gen_inject" }],
            [{ text: "📱 Basic Pack", callback_data: "gen_basic" }]
          ]
        }
      };

      bot?.sendPhoto(chatId, PAINEL_IMG, {
        caption: "🔑 *Gerador de Keys*\n\nSelecione o pack:",
        parse_mode: "Markdown",
        ...teclado
      });
      return;
    }

    // PROCESS ADMIN QUANTITY INPUT
    if (userId === ADMIN_ID && estado_usuarios[userId]?.etapa === "WAITING_GEN_QUANTITY") {
      if (!text || !/^\d+$/.test(text)) {
        bot?.sendMessage(chatId, "❌ Envie apenas um número.");
        return;
      }

      const qtd = parseInt(text);
      const pack = estado_usuarios[userId].pack;
      const info = PRODUTOS[pack as keyof typeof PRODUTOS];

      try {
        const newKeys = await storage.generateBatchKeys(info.nome, pack.toUpperCase(), qtd);
        const keyList = newKeys.map(k => `\`${k.key}\``).join('\n');

        bot?.sendMessage(chatId, 
          "🔐 *Keys geradas com sucesso*\n\n" +
          `📦 Pack: \`${pack.toUpperCase()}\`\n` +
          `🔢 Quantidade: \`${qtd}\`\n\n` +
          keyList, 
          { parse_mode: "Markdown" }
        );
        delete estado_usuarios[userId];
      } catch (error) {
        bot?.sendMessage(chatId, "❌ Erro ao gerar chaves.");
      }
      return;
    }

    // KEY VALIDATION (FOR USERS)
    if (estado_usuarios[userId]?.etapa === "WAITING_KEY_VALIDATION" && text) {
      const productSlug = estado_usuarios[userId].pack;
      const info = PRODUTOS[productSlug as keyof typeof PRODUTOS];
      const key = text.toUpperCase();

      try {
        const keyRecord = await storage.getKeyByValue(key);

        if (!keyRecord || keyRecord.productName !== info.nome) {
          bot?.sendMessage(chatId, "❌ *Chave inválida ou incorreta para este produto.*", { parse_mode: "Markdown" });
          return;
        }

        if (keyRecord.isUsed) {
          bot?.sendMessage(chatId, "❌ *Essa key já foi utilizada.*", { parse_mode: "Markdown" });
          return;
        }

        try {
          const link = await bot!.createChatInviteLink(info.grupo, { member_limit: 1 });
          await storage.markKeyAsUsed(keyRecord.id, userId, username);

          bot?.sendMessage(chatId, 
            `✅ *Pack liberado com sucesso!*\n\n👉 ${link.invite_link}`,
            { parse_mode: "Markdown" }
          );
          delete estado_usuarios[userId];
        } catch (error) {
          bot?.sendMessage(chatId, "⚠️ Erro ao gerar o link. Verifique se o bot é admin.");
        }
      } catch (error) {
        bot?.sendMessage(chatId, "❌ Erro ao validar chave.");
      }
      return;
    }
  });

  bot.on('callback_query', async (callbackQuery) => {
    const userId = callbackQuery.from.id.toString();
    const data = callbackQuery.data;
    const chatId = callbackQuery.message?.chat.id;

    if (!chatId || !data) return;

    if (data === "resgatar_pack") {
      const teclado = {
        reply_markup: {
          inline_keyboard: [
            [{ text: "🧪 Pharmacy Pack", callback_data: "pack_pharmacy" }],
            [{ text: "💉 Inject Pack", callback_data: "pack_inject" }],
            [{ text: "📱 Basic Pack", callback_data: "pack_basic" }]
          ]
        }
      };

      bot.sendPhoto(chatId, PAINEL_IMG, {
        caption: "🔑 *Selecione o pack para resgatar:*",
        parse_mode: "Markdown",
        ...teclado
      });
      bot.answerCallbackQuery(callbackQuery.id);
    } else if (data.startsWith("pack_")) {
      const pack = data.replace("pack_", "");
      estado_usuarios[userId] = { etapa: "WAITING_KEY_VALIDATION", pack: pack };

      bot.sendMessage(chatId, `🔐 *Envie sua key para o* \`${pack}\`:`, {
        parse_mode: "Markdown"
      });
      bot.answerCallbackQuery(callbackQuery.id);
    } else if (data.startsWith("gen_")) {
      const pack = data.replace("gen_", "");
      estado_usuarios[userId] = { etapa: "WAITING_GEN_QUANTITY", pack: pack };

      bot.sendMessage(chatId, 
        `📦 *Pack selecionado:* \`${pack}\`\n\n` +
        "👉 Envie agora *apenas o número* de keys:", 
        { parse_mode: "Markdown" }
      );
      bot.answerCallbackQuery(callbackQuery.id);
    }
  });

  bot.on("polling_error", (err) => console.log(err));
}
