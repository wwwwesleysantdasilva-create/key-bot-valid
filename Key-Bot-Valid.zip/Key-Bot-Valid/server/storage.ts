import { accessKeys, type AccessKey, type InsertAccessKey } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { nanoid } from "nanoid";

export interface IStorage {
  getKeys(): Promise<AccessKey[]>;
  generateKey(productName: string, prefix: string): Promise<AccessKey>;
  generateBatchKeys(productName: string, prefix: string, count: number): Promise<AccessKey[]>;
  getKeyByValue(value: string): Promise<AccessKey | undefined>;
  markKeyAsUsed(id: number, userId: string, username?: string): Promise<AccessKey>;
  deleteKey(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getKeys(): Promise<AccessKey[]> {
    return await db.select().from(accessKeys).orderBy(accessKeys.createdAt);
  }

  async generateKey(productName: string, prefix: string): Promise<AccessKey> {
    const key = `${prefix}-` + nanoid(6).toUpperCase();
    const [newKey] = await db.insert(accessKeys).values({ key, productName }).returning();
    return newKey;
  }

  async getKeyByValue(value: string): Promise<AccessKey | undefined> {
    const [key] = await db.select().from(accessKeys).where(eq(accessKeys.key, value));
    return key;
  }

  async generateBatchKeys(productName: string, prefix: string, count: number): Promise<AccessKey[]> {
    const values = Array.from({ length: count }, () => ({
      key: `${prefix}-` + nanoid(6).toUpperCase(),
      productName
    }));
    return await db.insert(accessKeys).values(values).returning();
  }

  async markKeyAsUsed(id: number, userId: string, username?: string): Promise<AccessKey> {
    const [updated] = await db
      .update(accessKeys)
      .set({ 
        isUsed: true, 
        usedAt: new Date(), 
        telegramUserId: userId,
        telegramUsername: username 
      })
      .where(eq(accessKeys.id, id))
      .returning();
    return updated;
  }

  async deleteKey(id: number): Promise<void> {
    await db.delete(accessKeys).where(eq(accessKeys.id, id));
  }
}

export const storage = new DatabaseStorage();
