import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { startBot } from "./bot";
import { api } from "@shared/routes";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Start the Telegram Bot
  startBot(storage);

  // Keep-alive route for 24/7 monitoring
  app.get('/', (req, res) => {
    res.send("🤖 Bot online 24/7");
  });

  // API Routes
  app.get(api.keys.list.path, async (req, res) => {
    const keys = await storage.getKeys();
    res.json(keys);
  });

  app.delete(api.keys.delete.path, async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID" });
    }
    await storage.deleteKey(id);
    res.status(204).send();
  });

  return httpServer;
}
