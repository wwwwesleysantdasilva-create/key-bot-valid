import { pgTable, text, serial, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const accessKeys = pgTable("access_keys", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  productName: text("product_name").notNull(),
  isUsed: boolean("is_used").default(false).notNull(),
  telegramUserId: text("telegram_user_id"),
  telegramUsername: text("telegram_username"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  usedAt: timestamp("used_at"),
});

export const insertAccessKeySchema = createInsertSchema(accessKeys).omit({ 
  id: true, 
  createdAt: true,
  usedAt: true,
  isUsed: true,
  telegramUserId: true,
  telegramUsername: true
});

export type AccessKey = typeof accessKeys.$inferSelect;
export type InsertAccessKey = z.infer<typeof insertAccessKeySchema>;
